/** Type Coercion */

console.log(5 + 5);

let num = '5' + 5;
console.log(typeof num);

let fullName = 'falak' + ' ' + 'Chandni';
console.log(fullName);

let sub = '55' - 10;
console.log(sub);

console.log('4' * 2);