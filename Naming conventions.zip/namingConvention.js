/** Rules and Naming Convention */

// 1. Case Sensitive
let year = 2020;
let Year = 2021;

// 2. Contains Alphabets(aA-zZ), numbers(0-9), underScore(_), Dollar($)
let name = "Falak";
let first_name = "Falak";
let amt$ = 29.5;
let num1 = 10;

// 3. Cannot start with a Number
let $num = 10;

// 4. No Reserved Keywords
//let let =10;

// 5. No Blank Spaces in between
let birthdate = 10;

// 6. under 10 or 15 characters

// 7. Variable names should always exist on the left hand
let a = 10;
//let 10 =b;

/* Naming Conventions */

// Relatable names for readability

// Snake Casing or camel Casing
