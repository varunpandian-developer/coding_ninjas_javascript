/** Operators in JS */

// 1. Assignment Operator(=)
let a = 10;
let b = a;
let c = (a = 20);

// console.log(a);
// console.log(b);
// console.log(c);

// 2. Arithematic Opeartors (+, -, *, /, %)
// console.log(10 + 2);
// console.log(10 - 2);
// console.log(10 * 2);
// console.log(10 / 2);
// console.log(11 % 2);

// 3. More Arithematic Operators (++, --, +, -, **)
let i = 2;
//i = i + 1;
//i++;

// console.log(++i);
//console.log(i ** 3);

// 4. Augmented Assignment Opeartor
// (+=, -=,*=, /=,.....)
//i = i+3;
i += 3;

console.log(i);
